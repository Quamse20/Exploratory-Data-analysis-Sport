
# coding: utf-8

# ## Introduction
# The Indian Premier League (IPL),is a professional Twenty20 cricket league in India contested during April and May of every year by teams representing Indian cities. The league was founded by the Board of Control for Cricket in India (BCCI) in 2007. The IPL is the most-attended cricket league in the world and ranks sixth among all sports league.
# 
# 
# 
# ## Objective
# 
# - Aim is to provide some interesting insights by analyzing the IPL data.
# - To find the team that won the most number of matches in a season.
# - To find the team that lost the most number of matches in a season.
# - Does winning toss increases the chances of victory.
# - To find the player with the most player of the match awards.
# - To find the city that hosted the maximum number of IPL matches.
# - To find the most winning team for each season.
# - To find the on-field umpire with the maximum number of IPL matches.
# - To find the biggest victories in IPL while defending a total and while chasing a total.
# 
# ## Variables Description
# 
# **The dataset has 18 columns. Let’s get acquainted with the columns.**
# - id: The IPL match id.
# - season: The IPL season
# - city: The city where the IPL match was held.
# - date: The date on which the match was held.
# - team1: One of the teams of the IPL match
# - team2: The other team of the IPL match
# - toss_winner: The team that won the toss
# - toss_decision: The decision taken by the team that won the toss to ‘bat’ or ‘field’
# - result: The result(‘normal’, ‘tie’, ‘no result’) of the match.
# - dl_applied: (1 or 0)indicates whether the Duckworth-Lewis rule was applied or not.
# - winner: The winner of the match.
# - win_by_runs: Provides the runs by which the team batting first won
# - win_by_runs: Provides the number of wickets by which the team batting second won.
# - player_of_match: The outstanding player of the match.
# - venue: The venue where the match was hosted.
# - umpire1: One of the two on-field umpires who officiate the match.
# - umpire2: One of the two on-field umpires who officiate the match.
# - umpire3: The off-field umpire who officiates the match

# In[1]:


## Importing Required Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
import warnings
warnings.filterwarnings('ignore')
get_ipython().run_line_magic('matplotlib', 'inline')


# In[2]:


## function to add data to plot
def annot_plot(ax,w,h):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    for p in ax.patches:
        ax.annotate('{}'.format(p.get_height()), (p.get_x()+w, p.get_height()+h))


# ### MATCHES DATASET
# 
# matches dataset contains data of all IPL matches from 2008 season till 2017 season.

# In[3]:


match=pd.read_csv('matches.csv')
match.sample(8)


# In[4]:


#1 Checking the dimension of the match dataframe
match.shape


# In[5]:


#2 Checking the data structure and also if there is missing value in any row in the data frame
match.info()


# In[6]:


#missing data
total = match.isnull().sum().sort_values(ascending=False)
percent = (match.isnull().sum()/match.isnull().count()).sort_values(ascending=False)
missing_data = pd.concat([total, percent], axis=1, keys=['Total', 'Percent'])
missing_data


# #### Let's analyse this to understand how to handle the missing data.
# 
# We'll consider that when more than 15% of the data is missing, we should delete the corresponding variable and pretend it never existed. This means that we will not try any trick to fill the missing data in these cases. According to this, there is just a variable (umpire3) that we should delete. The point is: will we miss this data? I don't think so. None of these variables seem to be very important, since most of them are not aspects in which actually related to the survival of passengers (maybe that's the reason why data is missing?).
# 
# In what concerns the remaining cases, we can see that (a) 'city' variable just have seven cases of missing data. Since it is just seven observation, we'll delete these observations and keep the variable. (b) 'player of match' variable just have four cases of missing data. Since it is just four observation, we'll delete these observations and keep the variable. (c) 'winner' variable just have four cases of missing data. Since it is just four observation, we'll delete these observations and keep the variable. (d) 'umpire1' variable just have two cases of missing data. Since it is just two observation, we'll delete these observations and keep the variable. (3) 'umpire2' variable just have two cases of missing data. Since it is just two observation, we'll delete these observations and keep the variable.
# 
# 
# *Regarding the remaining variables, we can see there were no missing cases.*
# 
# 
# 
# **The first thing to do before dropping values is to drop specific rows with no values or fill in the missing value with the mean**

# In[7]:


#droping the column from our dataset because it's not useful for analysis
match.drop(['umpire1','umpire2','umpire3'],axis=1,inplace=True)


# The variable (city, player of match, winner) cannot be filled with the mean value because it is not a numeric data, it doesn't have a mean, just letters.

# In[8]:


#dropping the rows in embarked that are missing and rechecking the data info
match.dropna(inplace=True);
match.info()


# ### Now we have data ready for our analysis
# **We have a complete dataset with no missing value**

# ## Number of matches played & Seasons we have got in the dataset

# In[51]:


#Desrciptive statistics
print("Number of matches played : ", match.shape[0])
print("Number of seasons : ", (match.season.unique()))
print("Length of seasons : ",len(match['season'].unique()))


# ## Number of Matches played in each IPL season

# In[9]:


ax=sb.countplot('season',data=match,palette="Set2")
plt.ylabel('Matches')
annot_plot(ax,0.08,1)


# **In 2013, we have the most number of matches**

# ## Matches Won By the Teams

# In[30]:


match.groupby('winner')['winner'].agg(['count']).sort_values('count').reset_index().plot(x='winner',y='count',kind='barh');


# **Mumbai Indians won maximum number of matches followed by Chennai Super Kings.**
# 
# **Mumbai Indians are the winners in most of the matches**

# ## PLAYER OF THE MATCH

# In[48]:


tops=match.player_of_match.value_counts()[:15]
tops


# In[47]:


top_players = match.player_of_match.value_counts()[:15]
plt.figure(figsize=(20,10))
ax=sb.barplot(x = top_players.index, y = top_players, orient='v', palette="Reds")
ax.set_ylim([0,20])
annot_plot(ax,0.05,1)
ax.set_ylabel("Count")
ax.set_title("Top player of the match Winners")
top_players.plot.bar()
plt.show();


# ### Observations:
# **Cris Gayle is the player who won the most player of the match awards and hence is the most valuable player.**
# 
# **CH Gayle is the most Successful player in all match winners**

# # Number of matches played in different cities

# In[19]:


match.city=match.venue.astype('category')


# In[20]:


#Checking number of matches played in a city in the match dataset
pd.DataFrame(match.city.value_counts())


# In[22]:


#Checking counts in our dataset with bar chart
plt.figure(figsize=(22,12))
plt.subplot(1,2,1);
match.city.value_counts().plot(kind='bar',title='MATCHES PLAYED BY CITY',color=['blue']);
plt.xlabel('Cities')
plt.ylabel('Counts');


# # Number of matches played in different stadiums

# In[10]:


match.venue=match.venue.astype('category')


# In[11]:


#Checking number of matches played in a venue in the match dataset
pd.DataFrame(match.venue.value_counts())


# In[14]:


#Checking counts in our dataset with bar chart
plt.figure(figsize=(22,12))
plt.subplot(1,2,1);
match.venue.value_counts().plot(kind='bar',title='MATCHES PLAYED BY VENUE',color=['red']);
plt.xlabel('Venue')
plt.ylabel('Counts');


# ### Observations:
# - Eden Gardens has hosted the maximum number of IPL matches followed by Wankhede Stadium and M Chinnaswamy Stadium.
# - Till 2019, IPL matches were hosted by 40 venues.

# ## Who won the most matches

# In[20]:


ax=sb.countplot(x='winner',data=match)
plt.ylabel('Match')
plt.xticks(rotation=80)
annot_plot(ax,0.05,1)


# In[22]:


#Checking number of winner in the matches dataset
pd.DataFrame(match.winner.value_counts())


# In[23]:


#Checking counts in our dataset with bar chart
plt.figure(figsize=(22,12))
plt.subplot(1,2,1);
match.winner.value_counts().plot(kind='bar',title='MATCH WON',color=['red']);
plt.xlabel('Winner')
plt.ylabel('Match');


plt.subplot(1,2,2);
win_values=[109,98,92,83,81,75,66,56,29,13,12,10,10,6,5]
win_labels=["mumbai","chennai","kolkata","royals","king","rajastan","dehli","sunrisers","decan","gujarat","pune","rising","dehli capital","kochi","rising pune"]
plt.axis("equal")
plt.title("Pie chart showing the Matches Won By Teams")
plt.pie(win_values,labels=win_labels,radius=1.0,autopct='%0.1f%%',shadow=True,explode=[0,0,0.1,0,0,0.1,0,0,0.1,0.1,0,0,0,0,0],wedgeprops={'edgecolor':'black'});


# ### Observations:
# **Mumbai Indians is the most successful team(as they have won the maximum number of IPL matches -109) followed by Chennai Super Kings and Kolkata Knight Riders.**
# 
# 

# ## (1)WIN PERCENTAGE

# In[32]:


match['win_by']=np.where(match['win_by_runs']>0,'Bat first','Bowl first')


# In[33]:


mat=match.win_by.value_counts()
mat


# In[29]:


labels=np.array(mat.index)
sizes = mat.values
colors = ['grey', 'yellow']
 
# Plot
plt.pie(sizes, labels=labels, colors=colors,
        autopct='%1.1f%%', shadow=True,startangle=90)

plt.title('Match Result')
plt.axis('equal')
plt.show()


# ### win percentage by season

# In[37]:


sb.countplot('season',hue='win_by',data=match,palette="Set1");


# In[39]:


#grouping two categorical variables together(season vs win by)
byd=match.groupby("season").win_by.value_counts()
byd


# In[40]:


#plotting clustered bar chart of win by vs season
byd=byd.reset_index(name='count')
byd.pivot(index='season',columns='win_by',values='count')


# In[41]:


sb.countplot(data=match,x='season',hue='win_by')
plt.xticks(rotation=15)
plt.legend(loc="lower left", bbox_to_anchor=(0.5, 1.15), ncol=2)

plt.title('Season Vs Win By');


# ## (2)TOSS DECISION

# In[42]:


toss=match.toss_decision.value_counts()
toss


# In[43]:


labels=np.array(toss.index)
sizes = toss.values
colors = ['gold', 'lightskyblue']
#explode = (0.1, 0, 0, 0)  # explode 1st slice
 
# Plot
plt.pie(sizes, labels=labels, colors=colors,
        autopct='%1.1f%%', shadow=True,startangle=90)

plt.title('Toss Result')
plt.axis('equal')
plt.show()


# In[44]:


#Checking counts in our dataset with bar chart
plt.figure(figsize=(10,4))
plt.subplot(1,2,1);
match.toss_decision.value_counts().plot(kind='bar',title='TOSS DECISION',color=['C4','C5']);
plt.xlabel('Toss Result')
plt.ylabel('Counts');

plt.subplot(1,2,2);
to_values=[463,293]
to_labels=["field","bat"]
plt.axis("equal")
plt.title("Pie chart showing the toss result")
plt.pie(to_values,labels=to_labels,radius=1.0,autopct='%0.1f%%',shadow=True,explode=[0,0.1],wedgeprops={'edgecolor':'black'});


# ### toss decision by season

# In[49]:


sb.countplot('season',hue='toss_decision',data=match,palette="Set1");


# In[50]:


#grouping two categorical variables together(season vs toss decision)
bya=match.groupby("season").toss_decision.value_counts()
bya


# In[52]:


#plotting clustered bar chart of toss decision vs season
bya=bya.reset_index(name='count')
bya.pivot(index='season',columns='toss_decision',values='count')


# In[54]:


sb.countplot(data=match,x='season',hue='toss_decision')
plt.xticks(rotation=15)
plt.legend(loc="lower left", bbox_to_anchor=(0.5, 1.15), ncol=2)

plt.title('Season Vs Toss Decision');


# # INDIAN PREMIER LEAGUE WINNERS BY SEASON

# In[57]:


final_matches=match.drop_duplicates(subset=['season'], keep='last')

final_matches[['season','winner']].reset_index(drop=True).sort_values('season')


# **Mumbai Indians has secured the most wins in four seasons(2010, 2013, 2017, and 2019). Mumbai Indians won the IPL trophy in 2013, 2015, 2017, and 2019.**

# # IPL Finals
# IPL Finals venues and winners along with the number of wins.

# In[58]:


final_matches.groupby(['city','winner']).size()


# ## WINNERS BY THEIR WIN BY RUNS

# In[64]:


#Grouping winner column
win_win=pd.DataFrame(match.groupby('winner').sum()['win_by_runs'])
win_win


# # Number of IPL seasons won by teams

# In[70]:


final_matches['winner'].value_counts()


# # Win Percentage in Finals

# In[71]:


match=final_matches.win_by.value_counts()
labels=np.array(match.index)
sizes = match.values
colors = ['gold', 'lightskyblue']
 
# Plot
plt.pie(sizes, labels=labels, colors=colors,
        autopct='%1.1f%%', shadow=True,startangle=90)

plt.title('Match Result')
plt.axis('equal')
plt.show()


# # TOSS DECISION IN FINALS

# In[72]:


toss=final_matches.toss_decision.value_counts()
labels=np.array(toss.index)
sizes = toss.values
colors = ['gold', 'lightskyblue']
#explode = (0.1, 0, 0, 0)  # explode 1st slice
 
# Plot
plt.pie(sizes, labels=labels, colors=colors,
        autopct='%1.1f%%', shadow=True,startangle=90)

plt.title('Toss Result')
plt.axis('equal')
plt.show()


# In[73]:


final_matches[['toss_winner','toss_decision','winner']].reset_index(drop=True)


# # Man of the Match in final match

# In[74]:


final_matches[['winner','player_of_match']].reset_index(drop=True)


# # Is winning the toss really an advantage?

# In[23]:


match['win_by_toss']=np.where(match['toss_winner']==match['winner'],'won','lost')


# In[24]:


tos=match.win_by_toss.value_counts()
tos


# In[25]:


labels=np.array(tos.index)
sizes = tos.values
colors = ['grey', 'yellow']
 
# Plot
plt.pie(sizes, labels=labels, colors=colors,
        autopct='%1.1f%%', shadow=True,startangle=90)

plt.title('HOW MUCH OF AN ADVANTAGE IS WINNING THE TOSS')
plt.axis('equal')
plt.show()


# **The probability of winning when the team had won the toss is 52%. So winning toss gives a slight edge over the opponent. However, it would be naive to term winning the toss as a greater advantage as there were 363 instances when the team losing the toss has won the game.**

# # OR

# In[55]:


match['tosw'] = 'no'
match['tosw'].ix[match.toss_winner == match.winner] = 'yes'


# In[58]:


temp_series = match.tosw.value_counts()

labels = (np.array(temp_series.index))
sizes = (np.array((temp_series / temp_series.sum())*100))
colors = ['gold', 'lightskyblue']
plt.pie(sizes, labels=labels, colors=colors,
        autopct='%1.1f%%', shadow=True, startangle=90)
plt.title("Toss winner is match winner")
plt.show()


# In[56]:


plt.figure(figsize=(12,6))
sb.countplot(x='toss_winner', hue='tosw', data=match)
plt.xticks(rotation='vertical')
plt.show()


# **It seems for Chennai Super Kings (CSK) winning the toss is an indication of winning the match with high probability.**
# 
# *On the other hand, Pune Warriors end up losing the matches more often when they won the toss.*
# 
# **So far we have looked at the match data to get insights. Now let us look at the delivery dataset which is more granular to gain some more insights. To start with, let us look at the top few rows.**
